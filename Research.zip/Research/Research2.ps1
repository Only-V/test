# Definition of parameters to run the script correctly
Param(
    [Parameter(Mandatory=$True,Position=1)]
    [string]$path,

    [Parameter(Mandatory=$True,Position=2)]
    [string]$type,

    [Parameter(Mandatory=$False)]
    [string]$wordlist,

    [Parameter(Mandatory=$False)]
    [String]$patterns
)

# Default values
if ( [string]::IsNullOrWhiteSpace($Wordlist) ){ $wordlist = 'wordlists\passwords.txt' }
if ( [string]::IsNullOrWhiteSpace($Patterns) ){ $patterns = 'patterns\passwords.txt' }

# Validation for $Type to ensure it has a valid value
if ($Type -notin @("all", "directories", "files")) {
    do {
        $Type = Read-Host "Please enter a valid Type (all, directories, or files)"
    } while ($Type -notin @("all", "directories", "files"))
}

# Date
$Date = Get-Date -Format "yyyy-MM-dd_HH-mm"

# Variables
$My_PATH = $path
$Type_Scan = $type
$My_Wordlist = Get-Content -Path $wordlist
$My_Patterns = Get-Content -Path $patterns

# Tables
$Files_Found = @()
$Patterns_Found = @()
$Ext = @('.txt','.csv','.sql','.ps1','.vba','.vbs','.bat','.hta','.xml','.json')
$Blacklist = @(
    "..."
)

Write-Host "




  _____                               _
 |  __ \                             | |
 | |__) |___  ___  ___  ____ ________| |__
 |  _  // _ \/ __|/ _ \/ _  | '__/ __| '_ \
 | | \ \  __/\__ \  __/ (_| | | | (__| | | |
 |_|  \_\___||___/\___|\____|_|  \___|_| |_|

                                            " -ForegroundColor Magenta
Write-Host "Scanning tree..." -ForegroundColor Magenta
Write-Host ""

# Convert the size of files in MB
function Size($tab) {
    $Return_Value = @()
    $uniqueFiles = $tab | Sort-Object -Unique
    foreach ($element in $uniqueFiles) {
        $sizeInBytes = (Get-Item $element).Length
        $sizeInMb = [math]::Round($sizeInBytes / 1MB, 2)
        if($sizeInMb -lt 20) {
            $Return_Value += "$sizeInMb MB : $element"
        }
    }
    return $Return_Value
}

# count Files/Patterns value
$lineFiles = (Get-Content $Wordlist | Measure-Object -Line).lines
$linePatterns = (Get-Content $Patterns | Measure-Object -Line).lines
Write-Host "Files in wordlist $Wordlist :"$lineFiles -ForegroundColor Yellow
Write-Host "Patterns in wordlist $Patterns :"$linePatterns -ForegroundColor Yellow
Write-Host ""

# Initialize parameters for scanning the tree
Write-Host "Extracting Files..." -ForegroundColor Magenta
[System.Collections.ArrayList]$MyFiles = @()
$Files = Get-ChildItem -Path "$My_PATH" -Recurse -File -ErrorAction SilentlyContinue
$TotalFiles = $Files.Count

# Print the total of files
Write-Host ""
Write-Host $TotalFiles" files in total" -ForegroundColor Yellow

# Print the start of indexing
Write-Host ""
Write-Host "Indexing Files..." -ForegroundColor Magenta
Write-Host ""

# Creation of a progress bar
for ($i = 0; $i -lt $TotalFiles; $i++) {
    [void]$MyFiles.Add($Files[$i])
    
    # Update every 100 files
    if ($i % 100 -eq 0) {
        Write-Progress -Activity "Searching for Text files recursively" `
                       -Status $Files[$i].FullName `
                       -CurrentOperation ("Files Collected: {0:N0}" -f $MyFiles.Count) `
                       -PercentComplete (($i / $TotalFiles) * 100)
    }
}

# Finalize the progress bar
Write-Progress -Activity "Searching for Text files recursively" -Status "Completed" -PercentComplete 100

# Confirm the scan of the tree and start the analyze of files
Write-Host "Searching for files..." -ForegroundColor Magenta
Write-Host ""
Write-Host "========================================"

# Loop
foreach ($File in $Files) {
    $CurrentFile++

    # Creation of a progress bar
    Write-Progress 	-Activity "Treatment of files" `
                    -Status "File $CurrentFile on $TotalFiles $($File.FullName)" `
                    -PercentComplete (($CurrentFile / $TotalFiles) * 100)

    # Scan for Type All and Type Directories
    if (($Type_Scan -eq "all") -or ($Type_Scan -eq "directories"))  {
        foreach ($Name in $My_Wordlist) {
            if ($File.Name -like "*$Name*") {
                $Files_Found += $File.FullName
                Write-Host "`r$([string]::new(' ', $Host.UI.RawUI.WindowSize.Width - 1))" -NoNewLine
                Write-Host -NoNewLine "`rFile> $($File.Name)" -ForegroundColor Cyan
            }
        }
    }

    # Scan for Type All and Type Files
    if (($Type_Scan -eq "all") -or ($Type_Scan -eq "files")) {

        # Research of patterns in files with the extention
        if ($File.Extension -match ($Ext -Join "|") ) {
            $skipFile = $false

            # Ignore the PATH in blacklist
            foreach ($Blacklisted_PATH in $Blacklist) {
                if ($File.FullName -like "$Blacklisted_PATH*") {
                    $skipFile = $true
                    break
                }
            }

            if (-not $skipFile) {
                $CurrentPattern = 0

                foreach ($Word in $My_Patterns) {
                    $CurrentPattern++

                    if ($File.FullName.Length -lt 245) {
                        $Patterns_Found += Select-String -Path $File.FullName -Pattern $Word -ErrorAction SilentlyContinue
                        Write-Host "`r$([string]::new(' ', $Host.UI.RawUI.WindowSize.Width - 1))" -NoNewLine
                        Write-Host -NoNewLine "`rPattern> $($word) $($File.Name)" -ForegroundColor Cyan
                    }
                }
            }
        }
    }  
}

# End of the progress bar
Write-Progress -Activity "Treatment is over" -Completed

# Output based on the files found
if (($Files_Found.Count -eq 0) -or ($Type_Scan -eq "all") -or $Type_Scan -eq "directories") {
    Write-Host ""
    Write-Host ""
    Write-Host "Files have been found" -ForegroundColor Cyan
    Size($Files_Found) | Out-File ".\data\$Date` Files.txt"
}
else {
    Write-Host ""
    Write-Host "No files have been found" -ForegroundColor Cyan
}

# Output based on the patterns found
if (($Patterns_Found.Count -eq 0) -or ($Type_Scan -eq "all") -or ($Type_Scan -eq "files")) {
    Write-Host ""
    Write-Host "Patterns in files have been found" -ForegroundColor Cyan
    foreach ($i in $Patterns_Found) {
        $i.ToString() | Out-File ".\data\$Date` Patterns.txt" -Append
    }
}
else {
    Write-Host ""
    Write-Host "No patterns have been found" -ForegroundColor Cyan
}

# End of code
if (($Patterns_Found.Count -gt 0) -or ($Files_Found.Count -gt 0)) {
    Write-Host ""
    Write-Host "All data has been saved in the directory .\data" -ForegroundColor Green
}
else {
    Write-Host ""
    Write-Host "No data has been found"
}
