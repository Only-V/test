# Research

**Research** is a tool designed to search for specific keywords across your entire machine.

## Installation

1. Clone this repository to your environment :

```bash
git clone https://github.com/Vault-of-Jok3r/Research.git
```

2. Navigate to the repository :

```bash
cd Research
```
## How It Works

The script should be executed with the following command :

```powershell
.\Research.ps1 -path <your_path> -type <the_type_wanted> -wordlist <your_wordlist> -pattern <your_pattern>
```

This script is designed to scan a specified directory for files and content matching certain criteria. It can search for filenames containing keywords from a wordlist or for specific patterns within file contents. The results are saved in organized output files.

### Parameters

The script accepts the following parameters:

- **`$path`** *(Mandatory)*: The path of the directory to scan.
- **`$type`** *(Mandatory)*: The type of scan to perform (`all`, `directories`, or `files`).
- **`$wordlist`** *(Optional)*: Path to a file containing keywords for filename matching (default: `wordlists\passwords.txt`).
- **`$patterns`** *(Optional)*: Path to a file containing patterns to search for within files (default: `patterns\passwords.txt`).

### Default Values

If no wordlist or patterns file is provided, the script defaults to:

- Wordlist: `wordlists\passwords.txt`
- Patterns: `patterns\passwords.txt`

### Workflow

1. **Parameter Validation**:
   - Ensures `$type` is one of the allowed values (`all`, `directories`, or `files`).
   - If invalid, prompts the user to enter a valid value.

2. **Initialization**:
   - Sets the current date for result file naming.
   - Loads the wordlist and patterns into variables for use during the scan.

3. **File Scanning**:
   - Recursively scans the directory specified in `$path`:
     - If `directories` or `all` is selected, searches filenames for matches with keywords from the wordlist.
     - If `files` or `all` is selected, examines the contents of files with specific extensions (e.g., `.txt`, `.json`) for patterns.

4. **Progress Feedback**:
   - Displays progress bars during the file indexing and scanning phases.
   - Provides real-time updates on the number of files processed and matches found.

5. **Results**:
   - **Matching Filenames**: Logs matching files in `Files.txt` in the `.\data\` folder, along with their sizes.
   - **Pattern Matches**: Logs pattern matches in `Patterns.txt` in the same folder.

6. **Summary**:
   - At the end of the scan, displays a summary of the results:
     - The number of files and patterns found.
     - Confirmation that all data has been saved in the `.\data\` directory.

### Output Files

The script generates the following output files in the `.\data\` folder:

- **`Files.txt`**: Contains the paths and sizes of files matching keywords from the wordlist.
- **`Patterns.txt`**: Contains the details of pattern matches found within file contents.

## Notes

- The script excludes paths listed in the blacklist to avoid scanning unwanted directories.
- It limits file size for content scanning to improve performance.
